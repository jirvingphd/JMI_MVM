# JMI_MVM
This repo is a collection of functions made by James M Irving and Michael V Moravetz during Flatiron Data Science Bootcamp.
