# name = "JMI_MVM v0.1.3"
from .startup import *
from .functions import *



# help_ = print(f" Recommended Functions to try: \n tune_params_trees \n plot_hist_scat_sns & multiplot\n list2df & df_drop_regex\n plot_wide_kde_thin_bar & make_violinplot\n")
#functions.py
# import pandas as pd

# # List of Functions Included (plus abbrevs for imported packages i.e. sns, np, plt)
# import os.path
# import os
# import sys
# sys.path.append('') 
# sys.path.append(os.path.join(os.path.dirname(tools.py), '..'))


# df_functions = pd.DataFrame([x for x in dir() if '__' not in x])
# df_functions.columns=['Available_Functions']
# df_functions.set_index('Available_Functions',inplace=True)
# df_functions
# print("Imported the following:\n pandas (pd), numpy(np), matplotlib.pyplot(plt), matplotlib(mpl), seaborn(sns), IPython.display(display)")
